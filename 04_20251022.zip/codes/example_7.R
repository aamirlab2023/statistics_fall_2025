probabilities = c(0.2, 0.5, 0.8)
x <- c(0:10)

for (probability in probabilities) {
  p_x <- numeric(11)
  print(paste("Probability distribution for p = ", probability))
  for (i in 1:11){
    p <- dbinom(i-1, 10, probability)
    p_x[i] <- p
  }
  plot(x, p_x, col="blue", pch=19, xlab="x", ylab="P(x)")
  for (i in 1:11){
    xx <- c(i-1, i-1)
    yy <- c(0, p_x[i])
    lines(xx, yy, type="l", col="blue")
  }
}