# Probability and Statistics (MATH-365)

# Foundational Topics in R

# Dr. Aamir Alaud Din

# September 17, 2025

***

## Why Data Types

- Why are there data types in a computer programming language?

- Data Types in human communication

- Data Types in R

    - Logical
    
    - Numeric
    
    - Integer
    
    - Complex
    
    - Character
    
    - Raw

### Logical

- TRUE, FALSE

- Decision making

- No binary operations

- Operators are applicable

```r
x <- TRUE
print(class(x))
```

- Output

```
"logical"
```

### Numeric

- Math operations

- Measurement

```r
x <- 12.3
y <- 55
print(class(x))
print(class(y))
```

- Output

```
"numeric"
"numeric"
```

### Integer

- Math operations

- Counting

```r
x <- 5L
print(class(x))
```

- Output

```
"integer"
```

### Complex

- Math operations

- Imaginary numbers dealing

```r
x <- 2 + 5i
print(class(x))
```

- Output

```
"complex"
```

### Character

- No math operations

- Text processing

```r
x <- "Aamir"
y <- "TRUE"
z <- "23.5"
print(class(x))
print(class(y))
print(class(z))
```

- Output

```
"character"
"character"
"character"
```

### Raw

- No math operations

- ASCII codes or hexademical notation

```r
x <- CharToRaw("Hello")
print(x)
print(class(x))
```

- Output

```
48 65 6c 6c 6f
"raw"
```

## R-Objects

- R variables are not declared as some data type but they are assigned with R-Objects.

- Then data type of R becomes the R-Object.

- Type of R-objects are as follows.

  - Vectors

  - Lists

  - Matrices

  - Arrays

  - Factors

  - Data Frames

### Vectors

- Vectors in r are initialized with ```c()``` function.

- Elements of vectors can be any data types we discussed above.

- Mixed data types can also be elements of vectors.

```r
names <- c('Aayesha', 'Hashir', 'Fatimah', 'Shaheer')
print(names)
ages <- c(14, 12, 9, 7, 'Ages')
print(ages)
```

- Output

```
"Aayesha" "Hashir"  "Fatimah" "Shaheer"
"14"   "12"   "9"    "7"    "Ages"
```

- Vector elements can be called by their indices.

- In above example, the variable ```names``` has indices starting from 1 for ```Aayesha``` through 4 for ```Shaheer```.

```r
n1 <- names[1]
n2 <- names[1:3]
print(n1)
print(n2)
```

- Output

```
"Aayesha"
"Aayesha" "Hashir"  "Fatimah"
```

- What will be the output of the following r statement?

```r
ages <- c(14, 12, 9, 7, 'Ages')
print(ages[4] + 7)
```

- The following statement will work.

```r
ages <- c(14, 12, 9, 7, 'Ages')
print(as.numeric(ages[4]) + 7)
```

- Output

```
14
```

### Lists

- A list is an R-object which can contain many different types of elements inside it like vectors, functions and even another list inside it.

```r
lst1 <- list(c(1, 3, 5), 9.5, sin)
print(lst1)
print(lst1[3])
```

- Output

```
[[1]]
[1] 1 3 5

[[2]]
[1] 9.5

[[3]]
function (x)  .Primitive("sin")

[[1]]
function (x)  .Primitive("sin")
```

### Matrices

- A matrix is a two-dimensional rectangular data set.

- It can be created using a vector input to the matrix function.

- Indices are assigned column wise.

```r
M <- matrix(c('a', 'b', 'c', 'd', 'e', 'f'), nrow = 2, ncol = 3, byrow = TRUE)
print(M)
print(M[2,])
print(M[,2])
print(M[2,][2])
```

- Output

```
     [,1] [,2] [,3]
[1,] "a"  "b"  "c" 
[2,] "d"  "e"  "f" 
[1] "d" "e" "f"
[1] "b" "e"
[1] "e"
```

### Arrays

- While matrices are confined to two dimensions, arrays can be of any number of dimensions.

- The array function takes a dim attribute which creates the required number of dimension.

- In the below example we create an array with two elements which are 3x3 matrices each.

```r
arr <- array(c('red', 'green'), dim = c(3, 3, 2))
print(arr)
print(arr[,,2])
```

- Output

```
, , 1

     [,1]    [,2]    [,3]   
[1,] "red"   "green" "red"  
[2,] "green" "red"   "green"
[3,] "red"   "green" "red"  

, , 2

     [,1]    [,2]    [,3]   
[1,] "green" "red"   "green"
[2,] "red"   "green" "red"  
[3,] "green" "red"   "green"

     [,1]    [,2]    [,3]   
[1,] "green" "red"   "green"
[2,] "red"   "green" "red"  
[3,] "green" "red"   "green"
```

### Factors

- Factors are the r-objects which are created using a vector.
- It stores the vector along with the distinct values of the elements in the vector as labels.
- The labels are always character irrespective of whether it is numeric or character or Boolean etc. in the input vector.
- They are useful in statistical modeling.
- Factors are created using the `factor()` function.
- The `nlevels` functions gives the count of levels.

```r
apple_colors <- c('green', 'green', 'yellow', 'red', 'red', 'red', 'green')

apple_factors <- factor(apple_colors)

print(apple_factors)
print(nlevels(apple_factor))
```

- When we execute the above code, it produces the following result.

```
[1] green  green  yellow red    red    red    green 
Levels: green red yellow
[1] 3
```

### Data Frames

- Data frames are tabular data objects.
- Unlike a matrix in data frame each column can contain different modes of data.
- The first column can be numeric while the second column can be character and third column can be logical.
- It is a list of vectors of equal length.
- Data Frames are created using the `data.frame()` function.

```r
BMI <- 	data.frame(
   gender = c("Male", "Male","Female"), 
   height = c(152, 171.5, 165), 
   weight = c(81,93, 78),
   Age = c(42,38,26)
)
print(BMI)
```

- When we execute the above code, it produces the following result.

```
  gender height weight Age
1   Male  152.0     81  42
2   Male  171.5     93  38
3 Female  165.0     78  26
```

- Another environmental science related example is the survival of four aquatic species in seawater under different arsenic concentrations is given below.

```r
survival <- data.frame(
  species = c('Tuna', 'Prawns', 'Lobster', 'Crab'),
  quantity = c(50, 50, 50, 50),
  av_weight = c(125, 0.040, 0.95, 1.25),
  threshold_as = c(18, 24, 30 ,36),
  weight_18 = c(125, 0.04, 0.95, 1.25),
  weight_24 = c(120, 0.04, 0.92, 1.20),
  weight_30 = c(85, 0.02, 0.59, 0.89),
  weight_36 = c(40, 0.005, 0.32, 0.33),
  survive_18 = c(50, 50, 50, 50),
  sruvive_24 = c(45, 40, 46, 48),
  survive_30 = c(30, 20, 35, 38),
  survive_36 = c(18, 0, 24, 24)
)
print(survival)
print(survival$species)
print(survival$av_weight)
print(survival$weight_30)
print(survival$quantity)
print(survival$survive_30)
```

- The output is as shown below.

```
  species quantity av_weight threshold_as weight_18 weight_24 weight_30 weight_36 survive_18 sruvive_24 survive_30 survive_36
1    Tuna       50    125.00           18    125.00    120.00     85.00    40.000         50         45         30         18
2  Prawns       50      0.04           24      0.04      0.04      0.02     0.005         50         40         20          0
3 Lobster       50      0.95           30      0.95      0.92      0.59     0.320         50         46         35         24
4    Crab       50      1.25           36      1.25      1.20      0.89     0.330         50         48         38         24
[1] "Tuna"    "Prawns"  "Lobster" "Crab" 
[1] 125.00   0.04   0.95   1.25
[1] 50 50 50 50
[1] 30 20 35 38
```

## R Variables

- A variable provides us with named storage that our programs can manipulate.
- A variable in R can store an atomic vector, group of atomic vectors or a combination of many R objects.
- A valid variable name consists of letters, numbers and the dot or underline characters.
- The variable name starts with a letter or the dot not followed by a number.

|Variable Name|Validity|Reason|
|:---|:---|:---|
|var_name2.|Valid|Has letters, numbers, dot and underscore|
|var_name%|Invalid|Has the character '%'. Only dot(.) and underscore allowed|
|2var_name|Invalid|Starts with a number|
|.var_name|Valid|Can start with a dot(.) but the dot(.)should not be followed by a number|
|var.name|Valid|The dot(.) can be anywhere and no starting number|
|.2var_name|Invalid|The starting dot is followed by a number making it invalid|
|_var_name|Invalid|Starts with _ which is not valid|

### Variable Assignment

- The variables can be assigned values using leftward, rightward and equal to operator.
- The values of the variables can be printed using `print()` or `cat()` function.
- The `cat()` function combines multiple items into a continuous print output.

```r
# Assignment using equal operator.
var.1 = c(0,1,2,3)           

# Assignment using leftward operator.
var.2 <- c("learn","R")   

# Assignment using rightward operator.   
c(TRUE,1) -> var.3           

print(var.1)
cat ("var.1 is ", var.1 ,"\n")
cat ("var.2 is ", var.2 ,"\n")
cat ("var.3 is ", var.3 ,"\n")
```

- When we execute the above code, it produces the following result.

```
[1] 0 1 2 3
var.1 is  0 1 2 3 
var.2 is  learn R 
var.3 is  1 1 
```

- **Note** − The vector `c(TRUE,1)` has a mix of logical and numeric class.
- So logical class is coerced to numeric class making TRUE as 1.

### Data Type of a Variable

- In R, a variable itself is not declared of any data type, rather it gets the data type of the R - object assigned to it.
- So R is called a dynamically typed language, which means that we can change a variables data type of the same variable again and again when using it in a program.

```r
var_x <- "Hello"
cat("The class of var_x is ",class(var_x),"\n")

var_x <- 34.5
cat("  Now the class of var_x is ",class(var_x),"\n")

var_x <- 27L
cat("   Next the class of var_x becomes ",class(var_x),"\n")
```

- The output is shown below.

```
The class of var_x is  character 
   Now the class of var_x is  numeric 
      Next the class of var_x becomes  integer
```

### Finding Variables

- To know all the variables currently available in the workspace we use the `ls()` function.
- Also the `ls()` function can use patterns to match the variable names.

```r
print(ls())
```

- The execution leads to following results.

```
[1] "my var"     "my_new_var" "my_var"     "var.1"      
[5] "var.2"      "var.3"      "var.name"   "var_name2."
[9] "var_x"      "varname" 
```

- **Note** − It is a sample output depending on what variables are declared in your environment.
- The `ls()` function can use patterns to match the variable names.

```r
# List the variables starting with the pattern "var".
print(ls(pattern = "var"))   
```

- The output is as follows.

```
[1] "my var"     "my_new_var" "my_var"     "var.1"      
[5] "var.2"      "var.3"      "var.name"   "var_name2."
[9] "var_x"      "varname"
```

- The variables starting with dot(.) are hidden, they can be listed using `"all.names = TRUE"` argument to `ls()` function.

```r
print(ls(all.name = TRUE))
```

- The output is as follows.

```
[1] ".cars"        ".Random.seed" ".var_name"    ".varname"     ".varname2"   
[6] "my var"       "my_new_var"   "my_var"       "var.1"        "var.2"        
[11]"var.3"        "var.name"     "var_name2."   "var_x" 
```

### Deleting Variables

- Variables can be deleted by using the `rm()` function.
- Below we delete the variable var.3.
- On printing the value of the variable error is thrown.

```r
rm(var.3)
print(var.3)
```

- When we execute the above code, it produces the following result.

```
[1] "var.3"
Error in print(var.3) : object 'var.3' not found
```

- All the variables can be deleted by using the `rm()` and `ls()` function together.

```r
rm(list = ls())
print(ls())
```

- The output is shown below.

```
character(0)
```

## Operators in R

### Arithmetic Operators

**1. `+`**
Adds two vectors	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v+t)
```
**Output**
```c
[1] 10.0  8.5  10.0
```

**2. `-`**
Subtracts second vector from the first	

```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v-t)
```
**Output**
```c
[1] -6.0  2.5  2.0
```

**3. `*`**
Multiplies both vectors	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v*t)
```
**Output**
```c
[1] 16.0 16.5 24.0
```

**4. `/`**
Divide the first vector with the second	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v/t)
```
**Output**
```c
[1] 0.250000 1.833333 1.500000
```

**5. `%%`**
Give the remainder of the first vector with the second	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v%%t)
```
**Output**
```c
[1] 2.0 2.5 2.0
```

**6. `%/%	`**
The result of division of first vector with second (quotient)	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v%/%t)
```
**Output**
```c
[1] 0 1 1
```

**7. `^`**
The first vector raised to the exponent of second vector	
```r
v <- c(2, 5.5, 6)
t <- c(8, 3, 4)
print(v^t)
```
**Output**
```c
[1]  256.000  166.375 1296.000
```

### Relational Operators

**1. `>`**
Checks if each element of the first vector is greater than the corresponding element of the second vector.
```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v>t)
```
**Output**
```c
[1] FALSE  TRUE FALSE FALSE
```

**2. `<`**
Checks if each element of the first vector is less than the corresponding element of the second vector.	
```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v < t)
```
**Output**
```c
[1]  TRUE FALSE  TRUE FALSE
```

**3. `==`**
Checks if each element of the first vector is equal to the corresponding element of the second vector.	
```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v == t)
```
**Output**
```c
[1] FALSE FALSE FALSE  TRUE
```

**4. `<=`**
Checks if each element of the first vector is less than or equal to the corresponding element of the second vector.
```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v<=t)
```
**Output**
```c
[1]  TRUE FALSE  TRUE  TRUE
```

**5. `>=`**
Checks if each element of the first vector is greater than or equal to the corresponding element of the second vector.	

```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v>=t)
```
**Output**
```c
[1] FALSE  TRUE FALSE  TRUE
```

**6. `!=`**
Checks if each element of the first vector is unequal to the corresponding element of the second vector.	
```r
v <- c(2,5.5,6,9)
t <- c(8,2.5,14,9)
print(v!=t)
```
**Output**
```c
[1]  TRUE  TRUE  TRUE FALSE
```

### Logical Operators

**1. `&`**
It is called Element-wise Logical AND operator. It combines each element of the first vector with the corresponding element of the second vector and gives a output TRUE if both the elements are TRUE.	0 is FALSE and all other numbers are TRUE in R language.
```r
v <- c(3,1,TRUE,2+3i)
t <- c(4,1,FALSE,2+3i)
print(v&t)
```
**Output**
```c
[1]  TRUE  TRUE FALSE  TRUE
```

**2. `|`**
It is called Element-wise Logical OR operator. It combines each element of the first vector with the corresponding element of the second vector and gives a output TRUE if one the elements is TRUE.	
```r
v <- c(3,0,TRUE,2+2i)
t <- c(4,0,FALSE,2+3i)
print(v|t)
```
**Output**
```c
[1]  TRUE FALSE  TRUE  TRUE
```

**3. `!`**
It is called Logical NOT operator. Takes each element of the vector and gives the opposite logical value.	
```r
v <- c(3,0,TRUE,2+2i)
print(!v)
```
**Output**
```c
[1] FALSE  TRUE FALSE FALSE
```

**4. `&&`**
Called Logical AND operator. Takes first element of both the vectors and gives the TRUE only if both are TRUE.	
```r
v <- c(3,0,TRUE,2+2i)
t <- c(1,3,TRUE,2+3i)
print(v&&t)
```
**Output**
```c
[1] TRUE
```

**5. `||`**
Called Logical OR operator. Takes first element of both the vectors and gives the TRUE if one of them is TRUE.	
```r
v <- c(0,0,TRUE,2+2i)
t <- c(0,3,TRUE,2+3i)
print(v||t)
```
**Output**
```c
[1] FALSE
```

### Miscellaneous Operators

**1. `:`**
Colon operator. It creates the series of numbers in sequence for a vector.	
```r
v <- 2:8
print(v) 
```
**Output**
```c
[1] 2 3 4 5 6 7 8
```

**2. `%in%`**
This operator is used to identify if an element belongs to a vector.	
```r
v1 <- 8
v2 <- 12
t <- 1:10
print(v1 %in% t) 
print(v2 %in% t) 
```
**Output**
```c
[1] TRUE
[1] FALSE
```

**3. `%*%`**
This operator is used to multiply a matrix with its transpose.	
```r
M = matrix( c(2,6,5,1,10,4), nrow = 2,ncol = 3,byrow = TRUE)
t = M %*% t(M)
print(t)
```
**Output**
```c
      [,1] [,2]
[1,]   65   82
[2,]   82  117
```