<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>

<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📊 Probability and Statistics</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Journey Towards Probability Distributions and Inferential Statistics</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">📅 September 17, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>The Foundations</li>
    <li>Non-parametric Measures</li>
    <li>Probability: Area Under the Curve</li>
    <li><span style="font-size: 52px; line-height: 2.0;">$z$</span>-Score</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Data is the collection of information for analysis, interpretation, and decision-making.</li>
    <li>Data can be text (categorical) or numeric (discrete or continuous).</li>
    <li>Mean is the central value of the data (by weight) and it represents the data.</li>
    <li>Spread tells us how scattered or clustered the data is about mean.</li>
    <li>Standard deviation is a standard measure of dispersion or spread in the data.</li>
    <li>Natural distributions follow 68-95-99.7 empirical rule also known as the normal distributions.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Explain the terminologies and concepts required to understand probability distributions and inferential statistics.</li>
    <li>Describe the difference among probability distributions of discrete (binomial and Poisson) and continuous random variables.</li>
    <li>Explain the logic of <span style="font-size: 52px; line-height: 2.0;">$z$</span>-score and calculate it.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If we have to move from one city to another and there is a river or lake between these cities, a bridge is built for the commute.</li>
    <li>In the same way, if we have to study a subject with insufficient background or foundation, we need a bridge (some more foundational topics) to achieve the ultimate objectives of the course.</li>
    <li>The only reason of studying this topic is to have the foundation knowledge required to understand the upcoming lectures and the subject.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. The Foundations</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We start with som terminologies and their explanations.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Population vs Sample</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>First we define population and sample.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Population</div>
  <div class="definition-body">
    Population is an entire group under study or investigation. Its outcome is called a parameter.
  </div>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Sample</div>
  <div class="definition-body">
    A subset of individuals from a population. Its outcome is called a statistic.
  </div>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Examples of Population</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Average income of people in a country.</li>
    <li>Average working hours in a city.</li>
    <li>Average CGPA in a university.</li>
    <li>TDS in Jhelum river.</li>
    <li>PM<sub>2.5</sub> level in a city.</li>
    <li>Soil porosity in an area of land.</li>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Examples of Sample</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>1,000,000 individuals from a country to estimate average income in the country.</li>
    <li>500 individuals from a city to estimate working hours in the city.</li>
    <li>500 students from a university to estimate the average CGPA in the university.</li>
    <li>35 water samples from Jhelum river, each sample of <span style="font-size: 52px; line-height: 2.0;">$200\;mL$</span> to estimate TDS in the river.</li>
    <li>35 air samples from a city, each sample of <span style="font-size: 52px; line-height: 2.0;">$500\;mL$</span>, to estimate the PM<sub>2.5</sub> level in the city.</li>
    <li>100 soil samples from an area of land, each sample of <span style="font-size: 52px; line-height: 2.0;">$100\;g$</span>,  to estimate the soil porosity.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Differences</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We present the differences in the following table.</li>
  </ul>
</div>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 1.</strong> Differences between parameter and statistic.</p>

<table style="font-size: 52px; line-height: 2.0; text-align: left;">
    <tr>
        <th>Term</th>
        <th>Refers To</th>
        <th>Example</th>
        <th>Representation</th>
    </tr>
    <tr>
        <td>Statistic</td>
        <td>Sample</td>
        <td>Mean</br>Standard Deviation</td>
        <td><span style="font-size: 52px; line-height: 2.0;">$\bar x$</span></br><span style="font-size: 52px; line-height: 2.0;">$s$</span></td>
    </tr>
    <tr>
        <td>Parameter</td>
        <td>Population</td>
        <td>Mean</br>Standard Deviation</td>
        <td><span style="font-size: 52px; line-height: 2.0;">$\mu$</span></br><span style="font-size: 52px; line-height: 2.0;">$\sigma$</span></td>
    </tr>
</table>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Non-Parametric Measures</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Measure of Center</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Consider the following dataset of 9 observations</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; text-align: center;">$1, 10, 7, 9, 7, 3, 7, 7, 1$</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><span style="font-size: 52px; line-height: 2.0;">$\bar x = 5.78$</span></li>
    <li>Finding median is impossible as the data is unarranged.</li>
    <li>First we arrange data in ascending order as shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; text-align: center;">$1, 1, 3, 7, 7, 7, 7, 9, 10$</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Middle value <span style="font-size: 52px; line-height: 2.0;">$= 7 =$</span> Median</li>
    <li>Suppose we have an extreme observation in the data set which is $50$ as shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; text-align: center;">$1, 1, 3, 7, 7, 7, 7, 9, 10, 50$</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Mean <span style="font-size: 52px; line-height: 2.0;">$= \bar x = 10.2$</span> and Median <span style="font-size: 52px; line-height: 2.0;">$= 7$</span>.</li>
    <li>For extreme observations in the data</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>Mean changes and is therefore a non resistant measure of central tendency to extreme observations in the dataset.</li>
        <li>Median does not change and is therefore a resistant measure of central tendency to extreme observations in the dataset.</li>
      </ul>
    </div>
    <li>We see the major differences between these two measures of central tendency in the table below.</li>
  </ul>
</div>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 2.</strong> Differences between mean and median of a dataset.</p>

<table style="font-size: 52px; line-height: 2.0; text-align: left;">
    <tr>
        <th>Measure</th>
        <th>Mean</th>
        <th>Median</th>
    </tr>
    <tr>
        <td>Arrangement</td>
        <td>Not required</td>
        <td>Required</td>
    </tr>
    <tr>
        <td>Resistance to Extreme Observations</td>
        <td>No</td>
        <td>Yes</td>
    </tr>
    <tr>
        <td>Data Representation</td>
        <td>Good</td>
        <td>Poor</td>
    </tr>
    <tr>
        <td>Parameter</td>
        <td>Yes</td>
        <td>No</td>
    </tr>
</table>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Now we understand the formula for median logically.</li>
    <li>If the dataset has odd number of observations in the dataset, the median is given by the following formula.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
Median = \left( \frac{n+1}{2} \right)^{th}\;\;observation
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>It is also clear from the following figure.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0201.png" width="80%" alt="odd_median"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Median for dataset with odd number of observations.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>If there are even number of data points in the dataset, the following formula is used to compute the median of the dataset.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
Median = \frac{\left( \frac{n}{2} \right)^{th} observation + \left( \frac{n}{2} + 1 \right)^{th} observation}{2}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The following figure clarifies the formula logicallyl.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0202.png" width="80%" alt="even"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 2.</strong> Median for dataset with even number of observations.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Median, which is middle value of the dataset, is also called the second quartile of the dataset represented by Q<sub>2</sub>.</li>
    <li>It separates the top 50% observations from the bottom 50% observations.</li>
    <li>The median of the bottom 50% observations is called the first quartile, represented by Q<sub>1</sub>.</li>
    <li>In the complete dataset, Q<sub>1</sub> separated bottom 25% observations from the top 75% observations.</li>
    <li>Similarly, the median of the top 50% observations is called the third quartile of the dataset and is representd by Q<sub>3</sub>.</li>
    <li>Q<sub>3</sub> separates the bottom 75% observations from the top 25% observations.</li>
    <li>The figure below clarifies the idea of Q<sub>1</sub> and Q<sub>3</sub>.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0203.png" width="80%" alt="qs"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 3.</strong> First and third quartiles in a dataset.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A logical understanding of Q<sub>1</sub>, Q<sub>2</sub> or M, and Q<sub>3</sub> is shown below.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0205.png" width="80%" alt="logical_qs"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 4.</strong> Logical understanding of data quartiles.</figcaption>
</figure>
<br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>First Quartile:</strong> Median of first half of data.</li>
    <li><strong>Third Quartile: </strong>Median of second half of data.</li>
    <li><strong>Second Quartile: </strong>Middle or median of data.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Measure of dispersion</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Range = Maximum - Minimum</li>
    <li>Inter Quartile Range = IQR = Q<sub>3</sub> - Q<sub>1</sub></li>
    <li>These are not good measures of dispersion and are non-parametric measures.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Measure of Outliers</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In order to detect the outliers in the dataset, we measure the least value called the lower fence.</li>
    <li>Any value(s) in the dataset smaller than lower fence are outliers on left or lower side of the data.</li>
    <li>We also measure the extreme value called the upper fence.</li>
    <li>Any value(s) in the dataset greater than upper fence are the outliers on right or upper side of the data.</li>
    <li>Mathematically, they are computed using the following empirical formulas.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
Lower\;\;Fence = Q_1 - 1.5(IQR)
$$
</span>

<span style="font-size: 52px; line-height: 2.0;">
$$
Upper\;\;Fence = Q_3 + 1.5(IQR)
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Data points smaller than lower fence and greater than upper fence are outliers.</li>
    <li>Outliers are part of data and should not be thrown out of dataset.</li>
    <li>They must be investigated to deal with them.</li>
    <li>Boxplot below shows the median, quartiles, upper and lower fences, and the outliers.</li>
  </ul>
</div>

<br>
<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0204.png" width="80%" alt="outliers"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 5.</strong> Boxplot of a dataset showing median, quartiles, upper and lower fences, and outliers.</figcaption>
</figure>
<br>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Probability: Area Under the Curve</h2>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Probability</div>
  <div class="definition-body">
    Probability is the chance of occurrence or likelihood of an event.
  </div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Terminologies and Formula</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>Sample Space <span style="font-size: 52px; line-height: 2.0;">$(n(S))$: </span></strong>Set of all possible outcomes of a random experiment/process is called the sample space.</li>
    <li><strong>Number of Outcomes of Event A <span style="font-size: 52px; line-height: 2.0;">$(n(A))$: </span></strong>Number of occurrences of event A.</li>
    <li><strong>Event A: </strong>Event that nitrate level in Rawal lake is greater than <span style="font-size: 52px; line-height: 2.0;">$10\;mg/L$</span>.</li>
    <li><strong>Sample Space <span style="font-size: 52px; line-height: 2.0;">$(n(S))$: </span></strong>If total number of samples collected are 100, then <span style="font-size: 52px; line-height: 2.0;">$n(S) = 100$</span>.</li>
    <li><strong>Occurrence of Event A <span style="font-size: 52px; line-height: 2.0;">$(n(A))$: </span></strong>If thirty out of one hundred sample have nitrate level exceeding <span style="font-size: 52px; line-height: 2.0;">$10\;mg/L$</span>, then <span style="font-size: 52px; line-height: 2.0;">$n(A) = 30$</span>.</li>
    <li>Now, the probability of event A i.e., nitrate level exceeding <span style="font-size: 52px; line-height: 2.0;">$10\;mg/L$</span> represented by <span style="font-size: 52px; line-height: 2.0;">$P(A)$</span> is computed using the following formula.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
P(A) = \frac{n(A)}{n(S)} = \frac{30}{100} = 0.3
$$
</span>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Probability Model</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>The probability of an event can be between 0 and 1 inclusive.</li>
    <li>The sum of probabilities of all the events is equal to 1.</li>
  </ol>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The above probability rules can be written mathematically as shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li><span style="font-size: 52px; line-height: 2.0;">$0 \le P(x_i) \le 1$</span></li>
    <li><span style="font-size: 52px; line-height: 2.0;">$\sum P(x_i) = 1$</span></li>
  </ol>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In the above example of nitrate level exceeding <span style="font-size: 52px; line-height: 2.0;">$10\;mg/L$</span>, few samples with nitrate level exceeding <span style="font-size: 52px; line-height: 2.0;">$10\;mg/L$</span> correspond to rule 1 of probability model.</li>
    <li>The scenario in which all the 100 samples have nitrate level exceeding <span style="font-size: 52px; line-height: 2.0;">$100\;mg/L$</span>, correspond to rule 2 in the probability model.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Permutation and Combination: What? Why?</h3>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Random Variable</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A variable whose value is determined by outcome of a random process is the random variable.</li>
    <li>There are two types of random variables.</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="1">
        <li><strong>Discrete Random Variable:</strong> They are whole numbers and will be discussed in upcoming lectures.</li>
        <li><strong>Continuous Random Variable:</strong> They are continuous numbers and will also be discussed later in upcoming lectures.</li>
      </ol>
    </div>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Area Under the Curve</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We already know about the normal curve.</li>
    <li>Total area under the curve is 100% or 1.</li>
    <li>The area below any part of the curve is less than or equal to 1 (100%) and this corresponds to rule 1 of the probability model.</li>
    <li>Total area under normal curve is 1 (100%) and it corresponds to rule 2 of the probability model.</li>
    <li>So, area under the normal curve represents the probability of an event.</li>
    <li>For example, for a dataset with <span style="font-size: 52px; line-height: 2.0;">$\bar x = 25$</span> and <span style="font-size: 52px; line-height: 2.0;">$s=3.5$</span>, probability of the numbers between <span style="font-size: 52px; line-height: 2.0;">$\bar x$</span> and <span style="font-size: 52px; line-height: 2.0;">$\bar x - s$</span> is 34%  or 0.34.</li>
    <li><strong>Frequency Distribution: </strong>A frequency distribution is what we observe in the data actually.</li>
    <li><strong>Probability Distribution: </strong>This is the theoretical expectation value.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;"><span style="font-size: 52px; line-height: 2.0;">7. $z$</span>-Score</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Large datasets are usually normally distributed.</li>
    <li>Consider a dataset of 10,000 data points with <span style="font-size: 52px; line-height: 2.0;">$\mu = 79.63$</span> and <span style="font-size: 52px; line-height: 2.0;">$\sigma = 18.15$</span> which is normally distributed.</li>
    <li>In the dataset, there is a number <span style="font-size: 52px; line-height: 2.0;">$36.13$</span>.</li>
    <li>Where does this number lie relative to mean?</li>
    <li>Three standard deviations below the mean?</li>
    <li>Two standar deviations above the mean?</li>
    <li>How many standard deviations away is this data point relative to mean?</li>
    <li>It can found by the value of <span style="font-size: 52px; line-height: 2.0;">$z$</span>-score given by the following formula.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
z = \frac{x_i - \mu}{\sigma}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><span style="font-size: 52px; line-height: 2.0;">$x_i - \mu$</span> is the distance of <span style="font-size: 52px; line-height: 2.0;">$i$</span><sup>th</sup> observation from the mean value.</li>
    <li><span style="font-size: 52px; line-height: 2.0;">$\frac{x_i - \mu}{\sigma}$</span> is the number of standard deviations away from the mean.</li>
    <li>For the example posed above, we compute the <span style="font-size: 52px; line-height: 2.0;">$z$</span>-score.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
z = \frac{x_i - \mu}{\sigma} = \frac{36.13 - 79.63}{18.15} = -2.40
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>So, the data point 36.13 lies 2 standard deviations below the mean.</li>
    <li>Given the <span style="font-size: 52px; line-height: 2.0;">$z$</span>-score, mean, and standard deviation of a data point, its value can be computed using the following formula.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
x = \mu + \sigma z
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><span style="font-size: 52px; line-height: 2.0;">$z$</span>-scores and table of probabilities help us to determine the probabilities.</li>
    <li>We will look into finding probabilities with distribution in upcoming topics.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">8. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Population is entire group under study and sample is a part of population.</li>
    <li>Statistics based on mean and standard deviation is parametric statistics.</li>
    <li>Statistics based on median etc. and IQR etc is non-parametric statistics.</li>
    <li>Median is middle observation of data arranged in ascending order.</li>
    <li>First and third quartiles are the middle observations of first and second half of data, respectively, whereas, median is the second quartile.</li>
    <li>In non-parametric statistics median is the measure of center and range or IQR are the measure of dispersion.</li>
    <li>Data points less than lower fence and greater than upper fence are outliers and are important part of data showing variability.</li>
    <li>Area under the normal curve represents probability.</li>
    <li><span style="font-size: 52px; line-height: 2.0;">$z$</span>-Score tells how many standard deviations a data point is away from the mean.</li>
    <li><span style="font-size: 52px; line-height: 2.0;">$z$</span>-Scores help to determine probability of continuous random variables we will look into in detail in remaining part of the course.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">9. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Given the permeate flow rates of a reverse osmosis plant in units of <span style="font-size: 52px; line-height: 2.0;">$L/hr$</span> in the [data file](../datasets/exercise_1.xlsx). How many standard deviations are the first, second, and third quartiles away from the mean?</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">For the [dataset](../datasets/exercise_1.xlsx) of particulate matter (PM2.5),</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="a">
    <li>Find \(Q_1\), \(Q_2\), and \(Q_3\)</li>
    <li>Find IQR</li>
    <li>Find outliers</li>
    <li>Draw a box and whisker plot by hand</li>
  </ol>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Note:</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify; color: red;">This topic is covering a variety of topics (Probability in a nutshell). Grasping the in-depth concepts requires reading, clarifying the concepts, and solving exercises.</p>