<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>

<div style="background-color: black; padding: 20px; border-radius: 40px;">
  <h1 style="font-size: 82px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📈 Probability and Statistics</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: orange;">📝 Center and Spread of Data</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: red;">🎓 Dr. Aamir Alaud Din</h1>
  <h1 style="font-size: 72px; font-weight: bold; text-align: center; line-height: 2.0; margin: 0; color: green;">📅 September 10, 2025</h1>
</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Data</li>
    <li>Center of Data</li>
    <li>Spread of Data</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>To describe data and its types in your own words.</li>
    <li>To describe and compute the center of data.</li>
    <li>To describe and compute the spread of data.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>As per our general perception about data, it is a collection of numbers obtained by either measurements or surveys.</li>
    <li>When we collect data, we have a bunch of numbers, for example 20 observations of lead concentration in units of $(\mu g/L)$ in a lake which are given below.</li>
  </ul>
</div>

<div style="font-size: 52px; padding-left: 110px; line-height: 2.0;">

$$
20.33, 22.01, 14.56, 11.98, 25.19, 23.63, 15.53, 26.76, 23.99, 17.13, 
$$

$$
22.88, 18.33, 10.76, 21.95, 22.12, 16.35, 25.13, 21.02, 22.93, 27.60
$$

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Instead of these 20 observations, can there be a single number which represents these 20 observations?</li>
    <li>In other words, is there a single concentration value which represents the lead concentration in the lake?</li>
    <li>We are interested in computing that single number and this is one reason of studying this topic?</li>
    <li>Suppose, we find a way to compute a single representative lead concentration and after computation this concentration comes out to be $20\; \mu g/L$.</li>
    <li>Now the question is, "how far (minimum and maximum) the other observations are spread about the mean?"</li>
    <li>We are interested in computing that number which describes the spread of the data and this is the second reason of studying this topic.</li>
    <li>Before going into depth, we will start our discussion on data.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. Data</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Data is collection of facts, figures, or values.</li>
    <li>Data represent information about a population of interest.</li>
    <li>Data includes</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>Numbers</li>
        <li>Words</li>
        <li>Measurements</li>
        <li>Observations</li>
        <li>Description/Characteristics of Things</li>
      </ul>
    </div>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Data</div>
  <div class="definition-body">
    Data is information we collect for analysis, interpretation, and decision-making.
  </div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Types of Data</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Qualitative (Categorical) Data</li>
    <li>Qunatitative Data</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>Discrete Data</li>
        <li>Continuous Data</li>
      </ul>
    </div>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0101.png" width="80%" alt="data_types"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Types of data in statistical studies.</figcaption>
</figure><br>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Qualitative (Categorical) Data</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>It tells the quality or category of the data.</li>
        <li>Examples</li>
        <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
          <ul style="list-style-type:square">
            <li>Color of flame (orange, red, and blue etc.) in salt test is an example of experimental study.</li>
            <li>Gender (male or female) is an example of survey based study.</li>
          </ul>
        </div>
      </ul>
    </div>
    <li>Qunatitative Data</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ol style="a">
        <li>Discrete Data</li>
        <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
          <ul style="list-style-type:circle">
            <li>They are whole numbers used in counting.</li>
            <li>Examples</li>
            <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
              <ul style="list-style-type:square">
                <li>No. of dead fish in an experiment is an example of experimental study.</li>
                <li>No. of males infected with a bacteria is an example of survey study.</li>
              </ul>
            </div>
          </ul>
        </div>
        <li>Continuous Data</li>
        <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
          <ul style="list-style-type:circle">
            <li>They are the continuous (decimal point) numbers used in measurements.</li>
            <li>Examples</li>
            <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
              <ul style="list-style-type:square">
                <li>Concentration of hexachlorocyclohexane (HCH) in groundwater is an example of experimental study.</li>
                <li>Height of females in nutrition deficient areas is an example of survey study.</li>
              </ul>
            </div>
          </ul>
        </div>
      </ol>
    </div>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Center of Data</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Measure of Central Tendency</li>
    <li>Representative of a Group</li>
    <li>Central Value (Half Weight Left and Half Right)</li>
    <li>Statistical Term: Mean or Average</li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0102.png" width="80%" alt="mean"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 2.</strong> Graphical representation of mean value dividing data into two halves by weight.</figcaption>
</figure><br>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Mean or Average</div>
  <div class="definition-body">
    The mean is the sum of all values divided by the number of values.
  </div>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
Mean = \frac{Sum\;\;of\;\;All\;\;Values}{Number\;\;of\;\;Values}
$$

$$
\bar x = \frac{\sum_{i=1}^{n}x_i}{n}
$$
</span>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">where <span style="font-size: 52px; line-height: 2.0;">$\bar x$</span> is the mean value, <span style="font-size: 52px; line-height: 2.0;">$\sum x_i$</span> is the sum of all observations <span style="font-size: 52px; line-height: 2.0;">$x_i$</span> is the $i$<sup>th</sup> observation, and <span style="font-size: 52px; line-height: 2.0;">$n$</span> is the number of observations.</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Mean is the central value dividing data into two halves by weight.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
Weight\;on\;Left\;Side\;of\;Mean + Weight\;on\;Right\;Side\;of\;Mean=0
$$
</span>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 1.</strong> Proof of equal weights on both sides of mean value.</p>

<div style="font-size: 52px; line-height: 2.0; text-align: left;">

|Sr. No.|Observations $(x_i)$|Mean $(\bar x)$|$z = x_i - \bar x$|
|:---|:---|:---|:---|
|1|1.16|2.33|-1.17|
|2|1.79|2.33|-0.54|
|3|2.58|2.33|0.24|
|4|1.97|2.33|-0.37|
|5|2.56|2.33|0.23|
|6|1.75|2.33|-0.58|
|7|2.81|2.33|0.48|
|8|2.75|2.33|0.42|
|9|3.61|2.33|1.28|
|10|2.33|2.33|0.00|
||||$\sum z = 0.00$|

</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Spread of Data</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Spread is the variability of data about the mean.</li>
    <li>It shows how much the data points differ from the mean value.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Dispersion</div>
  <div class="definition-body">
    Dispersion tells us how scattered or clustered the data is.
  </div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Two datasets can have same mean but different spreads.</li>
    <li>Different measures of spread are</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>Range $(Maximum - Minimum)$</li>
        <li>Inter Quartile Range (IQR)</li>
        <li>Mean Absolut Deviation (MAD)</li>
        <li>Variance</li>
        <li>Standard Deviation</li>
      </ul>
    </div>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Standard Deviation</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Deviation of one data point from mean $\bar x$ is given by</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
x_i - \bar x
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Total (sum of all) deviation is</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\sum(x_i - \bar x)
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We know that total deviation is always zero</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\sum(x_i - \bar x) = z = 0
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Squared deviation is not zero</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\sum(x_i - \bar x)^2 \ne 0
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Average of squared deviations is</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\frac{\sum(x_i - \bar x)^2}{n}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The unbiased squared deviations is</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
\frac{\sum(x_i - \bar x)^2}{n-1}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>This unbiased squared deviation is called variacne represented by $s^2$.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
s^2 = \frac{\sum(x_i - \bar x)^2}{n-1}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Square root of variance is called the standard deviation, represented by $s$.</li>
  </ul>
</div>

<span style="font-size: 52px; line-height: 2.0;">
$$
s = \sqrt{\frac{\sum(x_i - \bar x)^2}{n-1}}
$$
</span>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Standard means standard way of computing dispersion.</li>
  </ul>
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Find the location of center (mean) and dispersion (standard deviation) of the following data.</p>

<div style="font-size: 52px; padding-left: 110px; line-height: 2.0;">

$$
5.44,\;7.3,\;6.03,\;7.18,\;7.95,\;10.27,\;13.12\;5.59,\;8.10,\;8.26
$$

</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<span style="font-size: 52px; line-height: 2.0;">
$$
\bar x = \frac{\sum x_i}{n} = \frac{79.24}{10} = 7.92
$$
</span>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 2.</strong> Computation of standard deviation.</p>

<div style="font-size: 52px; line-height: 2.0; text-align: left;">

|Data $(x_i)$|Mean $(\bar x)$|Deviation $(z = x_i - \bar x)$|Squared Deviation $(z^2)$|
|:---|:---|:---|:---|
|5.44|7.92|-2.48|6.17|
|7.30|7.92|-0.62|0.39|
|6.03|7.92|-1.89|3.59|
|7.18|7.92|-0.74|0.55|
|7.95|7.92|0.03|0.00|
|10.27|7.92|2.35|5.50|
|13.12|7.92|5.20|27.0|
|5.59|7.92|-2.33|5.45|
|8.10|7.92|0.18|0.03|
|8.26|7.92|0.34|0.11|
||||$\sum (x_i - \bar x)^2 = 59.70$|
||||$\frac{\sum (x_i - \bar x)^2}{n-1} = 6.63$|
||||$\sqrt{\frac{\sum (x_i - \bar x)^2}{n-1}} = 2.58$|

</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>With $\bar x$ as Mean and $s$ as Standard Deviation of a Dataset</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>Data Lower Bound: $\bar x - 3s$</li>
        <li>Data Upper Bound: $\bar x + 3s$</li>
      </ul>
    </div>
    <li>99.7% of data lies within three standard deviations about the mean.</li>
    <li>In Example 1, $\bar x = 7.92$ and $s=2.58$.</li>
    <li>99.7% of data will be within $\bar x - 3s = 0.18$ and $\bar x + 3s = 15.66$.</li>
    <li>First standard deviation about mean covers 68% of data.</li>
    <li>Second standard deviation about mean covers 95% of data.</li>
    <li>Third standard deviation about mean covers 99.7% of data.</li>
    <li>Empirical rule is 68-95-99.7.</li>
    <li>Distribution following empirical rule is called normal distributions.</li>
    <li>Normal distributions is also called natural distributions.</li>
    <li></li>
  </ul>
</div>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0103.png" width="70%" alt="norm_dist"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 3.</strong> Distribution of data in normally distributed data.</figcaption>
</figure><br>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">For the dataset (<a href="../datasets/example_2.xlsx" download>click here to download</a>) show that empirical rule holds.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">In class activity</p>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Data is the collection of information for analysis, interpretation, and decision-making.</li>
    <li>Data can be text (categorical) or numeric (discrete or continuous).</li>
    <li>Mean is the central value of the data (by weight) and it represents the data.</li>
    <li>Spread tells us how scattered or clustered the data is about mean.</li>
    <li>Standard deviation is a standard measure of dispersion or spread in the data.</li>
    <li>Natural distributions follow 68-95-99.7 empirical rule also known as the normal distributions.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Compute the mean and standard deviation of lead concentration in Indus river in units of $\mu g/L$ for the dataset (<a href="../datasets/exercise_1.xlsx" download>click here to download</a>).</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Compute the mean and standard deviation of lead concentration in Jhelum river in units of $\mu g/L$ for the dataset (<a href="../datasets/exercise_2.xlsx" download>click here to download</a>). What similarity and difference do you observe in the two datasets? Comment on the similarities and differences.</p>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Homework 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Using the dataset in the excel file (with excel file matching your student ID), compute mean and standard deviation. Use the data to find the proportion or number of data points lying within the following domains.</p>

<span style="font-size: 52px; line-height: 2.0;">
$\bar x - 3s \le x \le \bar x - 2.5s$</br>
$\bar x - 2.5s \le x \le \bar x - 2s$</br>
$\bar x - 2s \le x \le \bar x - 1.5s$</br>
$\bar x - 1.5s \le x \le \bar x - s$</br>
$\bar x - s \le x \le \bar x - 0.5s$</br>
$\bar x - 0.5s \le x \le \bar x$</br>
$\bar x \le x \le \bar x + 0.5s$</br>
$\bar x + 0.5s \le x \le \bar x + s$</br>
$\bar x + s \le x \le \bar x + 1.5s$</br>
$\bar x + 1.5s \le x \le \bar x + 2s$</br>
$\bar x + 2s \le x \le \bar x + 2.5s$</br>
$\bar x + 2.5s \le x \le \bar x + 3s$
</span>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Using the proportions or number of data points in each of the above domains, plot a histogram and overlay a normal distribution curve over it. Your plot must look like the one shown below (bars and a curve on the same plot). The plot can be generated using the following normal distribution equation.</p>

<span style="font-size: 52px; line-height: 2.0;">
$$
f(x) = \frac{1}{s \sqrt{2 \pi}}e^{-\frac{1}{2}\left( \frac{x - \bar x}{s}\right)^2}
$$
</span>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0104.png" width="80%" alt="explot"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 4.</strong> Representation of normal distribution with histogram and normal distribution curve.</figcaption>
</figure><br>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">Keys to Success</h3>

<div style="color: red; font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Start working from today.</li>
    <li>Deep, logical, and everytime thinking.</li>
    <li>Try whatever you think logically.</li>
    <li>Use of ChatGPT or other chatbots may lead to problem in MSE/ESE.</li>
  </ul>
</div>