# 📈 Probability and Statistics

# 📝 Prelude

# 🎓 Dr. Aamir Alaud Din

# 📅 September 10, 2025

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">Contents</h2>

## 1. About the Instructor

## 2. About the Course

## 3. About the Lectures

## 4. Assessments and Grading

## 5. Class Rules

## 6. Keys to Success

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">1. About the Instructor</h2>

- **Name:** Aamir Alaud Din

- **Highest Qualification:** PhD

- **Specialized Areas of Teaching**

  - Mathematics

  - Computer Programming

  - Machine Learning

  - Artificial Intelligence
    
<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">2. About the Course</h2>

- **Course Title:** Probability and Statistics

- **Course Code:** MATH-365

- **Credit Hours:** 3 (2, 1)

    - **Theory:** 2

    - **Laboratory:** 1

- **Course Contents**

    - Parametric Statistics and the Parameters

    - Probability and Probability Distributions

    - Sampling Distribution of Sample Mean

    - Estimation of Population Parameters

    - Testing of Hypothesis

    - Difference between Two Means

    - $z$-Test and $t$-Test

    - Test of Association (chi-square)

    - Testing of Hypothesis About Variance

- **Course Material**

    - Learning Management System (LMS)

    - Github Repository

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">3. About the Lectures</h2>

- **Lecture Format**

    - Title and Topic

    - Outline/Contents

    - Recap

    - Objectives

    - The Why Section

    - Topic in Heirarchical Story

    - Summary

    - Exercises
        
- **Questions**

    - On Spot Questions

    - Questions to Instructor Only

    - No Fun/Jokes on Questions

    - Encourage Questions

    - Questions After the Lecture
        
- **Queries**

    - After the Class

    - In Office

    - Collective Questions and Queries through CR

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">4. Assessments and Grading</h2>

**Table 1.** Assessment and Grading for the course.

|Assessment Type|Count|Overall Weightage (%)|
|:----|:----:|:----:|
|Homeworks|Minimum 6|10|
|Quizzes|Minimum 6|15|
|Mid Semester Exam (MSE)|1|25|
|End Semester Exam (ESE)|1|50|

- Take Assessments Seriously (Last Semester 5F)

- Cell Phone on Dice Policy at Your Responsibility

- Handwritten Homeworks and Codes

- No Violation of Deadlines

- Submission within 24 Hourse After Deadline: 50% Reduction in Marks Obtained

- No Submission or Submission After 24 Hours of Deadline: Zero Marks

- Take Lab Reports Seriously

- Submission of Lab Report: Exactly as Mentioned Above

- Any Other Submission: Exactly as Mentioned Above

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">5. Class Rules</h2>

- Attendance Within First 15 Minutes Only (Take it Serious)

- Example: 0900 - 1000 Hours Class — Attendance will be closed at 0915 Hours on Alarm

- In Bag Cell Phone Policy

- Special Case Students (Academic + Medical + Others) Meetup

- Silence Zone

- Attendance: 75% Mandatory for ESE

- No Concept of Leave at NUST

- Emergency and Family Events: Use 25% Leverage on Attendance

- Make Up Classes

- Tutorial Sessions

- Take Class Rules Positively: A Non-Working Students Stands Face to Face of a Hard Working Student

- Class Rules: Professionalism

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">6. Keys to Success</h2>

- Conceptual Understanding

- Hard Work on Daily Basis

- **Lots of Practice Problems: <span style="color: red;">Practice, Practice, and Practice!!!**

- Lots of Computer Programs
