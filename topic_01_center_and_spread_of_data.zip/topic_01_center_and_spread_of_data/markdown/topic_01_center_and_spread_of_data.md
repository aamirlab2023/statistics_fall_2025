# 📈 Probability and Statistics (MATH-365)

# 📝 Center and Spread of Data

# 🎓 Instructor: Dr. Aamir Alaud Din

# 📅 Date: July 24, 2025


<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">Table of Contents</h2>

## 1. Objectives

## 2. The Why Section

## 3. Data

## 4. Center of Data

## 5. Spread of Data

## 6. Summary

## 7. Exercises


<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">1. Objectives</h2>

After taking this lecture and studying, you should be able to:

- To describe data and its types in your own words.

- To describe and compute the center of data.

- To describe and compute the spread of data.

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">2. Thy Why Section</h2>

- As per our general perception about data, it is a collection of numbers obtained by either measurements or surveys.

- When we collect data, we have a bunch of numbers, for example 20 observations of lead concentration in units of $(\mu g/L)$ in a lake which are given below.

$
20.33, 22.01, 14.56, 11.98, 25.19, 23.63, 15.53, 26.76, 23.99, 17.13, 22.88, 18.33, 10.76,
$

$
21.95, 22.12, 16.35, 25.13, 21.02, 22.93, 27.60
$

- Instead of these 20 observations, can there be a single number which represents these 20 observations?

- In other words, is there a single concentration value which represents the lead concentration in the lake?

- We are interested in computing that single number and this is one reason of studying this topic?

- Suppose, we find a way to compute a single representative lead concentration and after computation this concentration comes out to be $20\; \mu g/L$.

- Now the question is, "how far (minimum and maximum) the other observations are spread about the mean?"

- We are interested in computing that number which describes the spread of the data and this is the second reason of studying this topic.

- Before going into depth, we will start our discussion on data.

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">3. Data</h2>

- Collection of Facts, Figures, or Values

- Represent Information

- Data

    - Numbers

    - Words

    - Measurements

    - Observations

    - Description/Characteristics of Things

> **Definition: Data**
> Data is information we collect for analysis, interpretation, and decision-making.

### Types of Data

- Qualitative (Categorical) Data

- Qunatitative Data

    - Discrete Data

    - Continuous Data

![data_types](../images/0101.png)

**Figure 1.** Types of data in statistical studies.

1. Qualitative (Categorical) Data

    - Type: Quality or Category
    
    - Examples:
        
        - Color of Flame (Orange, Red, Blue) in Salt Test &mdash; Experimental Study
    
        - Gender (Male, Female) &mdash; Survey Study

2. Quantitative Data
    
    - Discrete Data
      
        - Type: Whole Number
        
        - Examples:

            - No. of Dead Fish (4, 6, and 7 etc.) &mdash; Experimental Study
            
            - No. of Males with Infection (3, 8, and 12 etc.) &mdash; Survey Study
    
    - Continuous Data

        - Type: Real Number

        - Examples:
            
            - Concentration of Hexachlorocyclohexane (HCH) in Ground Water (0.0002, 0.0007, and 0.00017 $mg/L$ etc.) &mdash; Experimental Study
            
            - Height of Females in Nutrition Deficient Areas (4.11, 5.05, 5.3 $ft$ etc.) &mdash; Survey Observation

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">4. Center of Data</h2>

- Measure of Central Tendency

- Representative of a Group

- Central Value (Half Weight Left and Half Right)

- Statistical Term: Mean or Average

![mean](../images/0102.png)

**Figure 2.** Graphical representation of mean value dividing data into two halves by weight.

> **Definition: Mean or Average**
> The mean is the sum of all values divided by the number of values.


$$
\text{Mean} = \frac{\text{Sum of All Values}}{\text{Number of Values}}
$$
    
$$
\bar x = \frac{\sum_{i=1}^n x_i}{n}
$$

- $\bar x$: Mean Value

- $\sum x_i$: Sum of All Observations

- $x_i$: $i$<sup>th</sup> Observation

- $n$: Number of Observations

- Mean: Central Value Dividing Data into Two Halves by Weight

$$
    \text{Weight on Left Side of Mean} + \text{Weight on Right Side of Mean} = 0
$$

**Table 1.** Proof of equal weights on both sides of mean value.

|Sr. No.|Observations $(x_i)$|Mean $(\bar x)$|$z = x_i - \bar x$|
|:---|:---|:---|:---|
|1|1.16|2.33|-1.17|
|2|1.79|2.33|-0.54|
|3|2.58|2.33|0.24|
|4|1.97|2.33|-0.37|
|5|2.56|2.33|0.23|
|6|1.75|2.33|-0.58|
|7|2.81|2.33|0.48|
|8|2.75|2.33|0.42|
|9|3.61|2.33|1.28|
|10|2.33|2.33|0.00|
||||$\sum z = 0.00$|

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">5. Spread of Data</h2>

- Spread or Variability

- Shows How Much the Data Points Differ from the Mean


> **Definition: Dispersion**
> Dispersion tells us how scattered or clustered the data is.


- Two Data Sets &mdash; Same Mean Different Spreads

- Measures of Spread

  - Range $(Maximum - Minimum)$

  - Inter Quartile Range (IQR)

  - Mean Absolute Deviation (MAD)

  - Variance

  - Standard Deviation (SD)

### Standard Deviation

- Deviation of One Data Point from Mean

$$
    x_i - \bar x
$$

- Total Deviation (of Data) from Mean

$$
    \sum(x_i - \bar x)
$$

- Total Deviation is Zero

$$
    \sum(x_i - \bar x) = z = 0
$$

- Squared Deviation

$$
    \sum(x_i - \bar x)^2 \ne 0
$$

- Average of the Squared Deviation

$$
    \frac{\sum(x_i - \bar x)^2}{n}
$$

- Unbiased Average Squared Deviation

$$
    \frac{\sum(x_i - \bar x)^2}{n - 1}
$$

- Variance

$$
    s^2 = \frac{\sum(x_i - \bar x)^2}{n - 1}
$$

- Standard Deviation

$$
    s = \sqrt{\frac{\sum(x_i - \bar x)^2}{n - 1}}
$$

- Standard &mdash; Standard Way of Computing Deviation

***

### Example 1
Find the location of center (mean) and dispersion (standard deviation) of the following data.

$$
5.44,\;7.3,\;6.03,\;7.18,\;7.95,\;10.27,\;13.12\;5.59,\;8.10,\;8.26
$$

**Solution**

Mean $= \bar x = \frac{\sum x_i}{n} = \frac{79.24}{10} = 7.92$

**Table 2.** Computation of standard deviation.

|Data $(x_i)$|Mean $(\bar x)$|Deviation $(z = x_i - \bar x)$|Squared Deviation $(z^2)$|
|:---|:---|:---|:---|
|5.44|7.92|-2.48|6.17|
|7.30|7.92|-0.62|0.39|
|6.03|7.92|-1.89|3.59|
|7.18|7.92|-0.74|0.55|
|7.95|7.92|0.03|0.00|
|10.27|7.92|2.35|5.50|
|13.12|7.92|5.20|27.0|
|5.59|7.92|-2.33|5.45|
|8.10|7.92|0.18|0.03|
|8.26|7.92|0.34|0.11|
||||$\sum (x_i - \bar x)^2 = 59.70$|
||||$\frac{\sum (x_i - \bar x)^2}{n-1} = 6.63$|
||||$\sqrt{\frac{\sum (x_i - \bar x)^2}{n-1}} = 2.58$|

- With $\bar x$ as Mean and $s$ as Standard Deviation of a Dataset
    
    - Data Lower Bound
    
    $$
        \bar x - 3s
    $$
    
    - Data Upper Bound
    
    $$
        \bar x + 3s
    $$
    
- 99.7% of Data Within Three Standard Deviations About the Mean

- Remaining 0.3% &mdash; Outside Three Standar Deviations About the Mean

- In Example 1, $\bar x = 7.92$ and $s=2.58$

- 99.7% of Data Will be Within $\bar x - 3s = 0.18$ and $\bar x + 3s = 15.66$

- First Standard Deviation About Mean: 68% of Data

- Second Standard Deviation About Mean: 95% of Data

- Third Standard Deviation About Mean: 99.7% of Data

- Empirical Rule: 68-95-99.7

- Distribution Following Empirical Rule &mdash; Normal Distributions

- Normal Distributions &mdash; Natural Distributions

![norm_dist](../images/0103.png)

**Figure 3.** Distribution of data in normally distributed data.

### Example 2 (In Class Activity)
For the data set ([Click to Download](../datasets/example_2.xlsx)), show that empirical rule holds.
### Solution
Class/Lab Activity

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">6. Summary</h2>

- Data is the collection of information for analysis, interpretation, and decision-making.

- Data can be text (categorical) or numeric (discrete or continuous).

- Mean is the central value of the data (by weight) and it represents the data.

- Spread tells us how scattered or clustered the data is about mean.

- Standard deviation is a standard measure of dispersion or spread in the data.

- Natural distributions follow 68-95-99.7 empirical rule also known as the normal distributions.

<h2 style="color: black; background-color: orange; border-left: 20px solid red; border-radius: 10px; line-height: 2.0;">7. Exercises</h2>

### Exercise 1
Compute the mean and standard deviation of lead concentration in Indus river in units of $\mu g/L$ for the dataset [click here to download](../datasets/exercise_1.xlsx).
    
### Exercise 2
Compute the mean and standard deviation of lead concentration in Jhelum river in units of $\mu g/L$ for the dataset [click here to download](../datasets/exercise_2.xlsx). What similarity and difference do you observe in the two datasets? Comment on the similarities and differences.

### Homework 1 (Due Next Week Same Day in Class)

Using the dataset in the excel file (with excel file matching your student ID), compute mean and standard deviation. Use the data to find the proportion or number of data points lying within the following domains.
    
$\bar x - 3s \le x \le \bar x - 2.5s$
$\bar x - 2.5s \le x \le \bar x - 2s$
$\bar x - 2s \le x \le \bar x - 1.5s$
$\bar x - 1.5s \le x \le \bar x - s$
$\bar x - s \le x \le \bar x - 0.5s$
$\bar x - 0.5s \le x \le \bar x$
$\bar x \le x \le \bar x + 0.5s$
$\bar x + 0.5s \le x \le \bar x + s$
$\bar x + s \le x \le \bar x + 1.5s$
$\bar x + 1.5s \le x \le \bar x + 2s$
$\bar x + 2s \le x \le \bar x + 2.5s$
$\bar x + 2.5s \le x \le \bar x + 3s$
    
Using the proportions or number of data points in each of the above domains, plot a histogram and overlay a normal distribution curve over it. Your plot must look like the one shown below (bars and a curve on the same plot). The plot can be generated using the following normal distribution equation.

$$
    f(x) = \frac{1}{s \sqrt{2 \pi}}e^{-\frac{1}{2}\left( \frac{x - \bar x}{s}\right)^2}
$$

![example_plot](../images/0104.png)

**Figure 1.** Representation of normal distribution with histogram and normal distribution curve.

### Keys to Success

- Start working from today.

- Deep, logical, and everytime thinking.

- Try whatever you think logically.