import numpy as np
import matplotlib.pyplot as plt

def norm_dist(mu, sigma, x):
    return (1/(sigma*np.sqrt(2*np.pi)))*np.exp(-(x - mu)**2/(2*sigma**2))

mu0 = 0
sigma0 = 1
mu1 = 3
sigma1 = 1
x0 = np.linspace(mu0 - 3.5*sigma0, mu0 + 3.5*sigma0, 500)
x1 = np.linspace(mu1 - 3.5*sigma1, mu1 + 3.5*sigma1, 500)
y0 = norm_dist(mu0, sigma0, x0)
y1 = norm_dist(mu1, sigma1, x1)

plt.figure(figsize=(12, 4))
plt.plot(x0, y0, '-b', linewidth=2)
plt.plot([mu0, mu0], [0, norm_dist(mu0, sigma0, mu0)], '--b')
plt.plot([-1, -1], [0, norm_dist(mu0, sigma0, -1)], '--b')
plt.plot([1, 1], [0, norm_dist(mu0, sigma0, 1)], '--b')

plt.plot(x1, y1, '-r', linewidth=2)
plt.plot([mu1, mu1], [0, norm_dist(mu1, sigma1, mu1)], '--r')
plt.plot([2, 2], [0, norm_dist(mu1, sigma1, 2)], '--r')
plt.plot([4, 4], [0, norm_dist(mu1, sigma1, 4)], '--r')

plt.xlabel("Data", size=26, weight='bold')
plt.ylabel("Frequency", size=26, weight='bold')
plt.xticks(size=26, weight='bold')
plt.yticks(size=26, weight='bold')
plt.tight_layout()

plt.show()