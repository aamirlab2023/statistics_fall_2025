import numpy as np
import matplotlib.pyplot as plt
"""
x = np.random.normal(87, 7.3, 1000)

plt.figure(figsize=(8, 6))
plt.hist(x, bins=12, edgecolor='black')
plt.xlabel("Data", size=26, weight='bold')
plt.ylabel("Frequency", size=26, weight='bold')
plt.xticks(size=26, weight='bold')
plt.yticks(size=26, weight='bold')
plt.tight_layout()
plt.savefig("./topic_06/images/0604.png")
plt.show()
"""
xlo = 87 - 7.3*3.5
xhi = 87 + 7.3*3.5

x = np.linspace(xlo, xhi, 1000)
y = (1/(7.3*np.sqrt(2*np.pi)))*np.exp((-1*(x - 87)**2)/(2*7.3**2))

plt.figure(figsize=(9, 7))
plt.plot(x, y, '-k')
plt.xlabel("Data", size=26, weight='bold')
plt.ylabel("Frequency", size=26, weight='bold')
plt.xticks(size=26, weight='bold')
plt.yticks(size=26, weight='bold')
plt.tight_layout()
plt.savefig("./topic_06/images/0605.png")
plt.show()



