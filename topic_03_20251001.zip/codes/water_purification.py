import matplotlib.pyplot as plt

f = open("../datasets/exercise_3.csv", "r")
lines = f.readlines()
f.close()

data = []
for line in lines:
    line = line.split()
    data.append(int(line[0]))

x = 0
y = 0
ylim =[]
for i in range(len(data)):
    x += 1
    y += data[i]
    ylim.append(y/x)
    print(x, data[i], y)
    plt.scatter(x, y/x, s=50, c='k')
mean = sum(ylim)/len(ylim)
plt.plot([0, 101], [mean, mean], '-b')
plt.xlim([0, 101])
plt.ylim([min(ylim) - 0.1, 3.5])
plt.xticks(size=12, weight='bold')
plt.yticks(size=12, weight='bold')
plt.xlabel("Number of Experiments", size=12, weight='bold')
plt.ylabel("Mean", size=12, weight='bold')
plt.show()