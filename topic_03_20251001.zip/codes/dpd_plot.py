import matplotlib.pyplot as plt

x = [0, 1, 2, 3]
px = [0.01, 0.10, 0.38, 0.51]

plt.plot([0, 0], [0, 0.01], '-b')
plt.plot([1, 1], [0, 0.10], '-b')
plt.plot([2, 2], [0, 0.38], '-b')
plt.plot([3, 3], [0, 0.51], '-b')
plt.scatter(x, px, c='b', s=50)
plt.xlabel("Number of Successful Filtrations", size=20, weight='bold')
plt.ylabel("Probability of Purification", size=20, weight='bold')
plt.xticks(size=20, weight='bold')
plt.yticks(size=20, weight='bold')
plt.grid(axis='y')
plt.xlim([-0.1, 3.5])
plt.tight_layout()
plt.show()