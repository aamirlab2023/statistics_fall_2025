<style>
  .line-container {
    position: relative;
    margin-left: 0px; /* spacing from other elements */
    margin-right: 0px;
    margin-top: 20px;
    margin-bottom: 20px;
  }
  .horizontal-line {
    height: 2px; /* Line thickness */
    background-color: blue; /* Line color */
    width: 100%; /* Full width line */
  }
  .top-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    top: 100%; /* Position just below the line */
    left: 0; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .bottom-box {
    width: 10px; /* Box width */
    height: 10px; /* Box height */
    background-color: red; /* Box color */
    position: absolute;
    bottom: 100%; /* Position just below the line */
    right: 0%; /* Align to the left side */
    margin-top: 0px; /* Optional spacing between line and box */
  }
  .definition-box {
    width: 100%;
    border: 2px solid navy;
    border-radius: 5px;
    overflow: hidden;
  }
  .definition-header {
    background-color: navy;
    color: white;
    padding: 10px;
    font-weight: bold;
    font-size: 52px;
  }
  .definition-body {
    background-color: white;
    color: navy;
    padding: 15px;
    line-height: 2.0;
    text-align: justify;
    font-size: 52px;
  }
</style>

<div style="font-size: 80px; font-weight: bold; text-align: center; background-color: black;padding: 30px; margin-left: 10px; margin-right: 10px; border-bottom: solid red 5px; line-height: 2.0;">

📈 <span style="color: white;">Probability and Statistics</span>
📝 <span style="color: orange;">Discrete Probability Distributions</span>
🎓 <span style="color: red;">Dr. Aamir Alaud Din</span>
📅 <span style="color: green;">September 25, 2025</span>

</div>
<br><br><br>

<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">Contents</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ol type="1">
    <li>Recap</li>
    <li>Objectives</li>
    <li>The Why Section</li>
    <li>Discrete Random Variable and Probability Distribution</li>
    <li>Mean of Discrete Random Variable</li>
    <li>Standard Deviation of Discrete Random Variable</li>
    <li>Summary</li>
    <li>Exercises</li>
  </ol>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">1. Recap</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Population is entire group under study and sample is a part of population.</li>
    <li>Statistics based on mean and standard deviation is parametric statistics.</li>
    <li>Statistics based on median etc. and IQR etc is non-parametric statistics.</li>
    <li>Median is middle observation of data arranged in ascending order.</li>
    <li>First and third quartiles are the middle observations of first and second half of data, respectively, whereas, median is the second quartile.</li>
    <li>In non-parametric statistics median is the measure of center and range or IQR are the measure of dispersion.</li>
    <li>Data points less than lower fence and greater than upper fence are outliers and are important part of data showing variability.</li>
    <li>Area under the normal curve represents probability.</li>
    <li>\(z\)-Score tells how many standard deviations a data point is away from the mean.</li>
    <li>\(z\)-Scores help to determine probability of continuous random variables we will look into in detail in remaining part of the course.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">2. Objectives</h2>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">After <span style="color: green;">taking this lecture</span> and <span style="color: red;">studying</span>, you should be able to:</p>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Describe and explain discrete random variable.</li>
    <li>Identify a discrete probability distribution and graph it.</li>
    <li>Compute and interpret mean of discrete probability distribution.</li>
    <li>Compute and interpret standard deviation of discrete probability distribution.</li>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">3. The Why Section</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>In any lab experiment, if we perform an experiment 100 times, we get similar (not 100% same) results.</li>
    <li>Sometimes, we have special data which can have only few possible outcomes.</li>
    <li>If we perform experiment 100 times, the answer will always be 0, 1, or 2.</li>
    <li>Moreover, this type of repetetive data is discete and has probabilities associated with them.</li>
    <li>In such cases, the distribution is not continuous and we are not interested in the probability of values from 75.3 to 79.8 because our data is discrete and this range is continuous.</li>
    <li>The reason of studying this topic is to understand</li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
    <ul style="list-style-type:disk">
        <li>How to work with discrete data?</li>
        <li>How to plot the distribution of these numbers? After all these are only few values?</li>
        <li>How to compute the mean of such data?</li>
        <li>How to compute standard deviation of such data?</li>
    </ul>
    </div>
  </ul>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">4. Discrete Random Variable and Probability Distribution</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>First we define probability experiment and link it to discrete random variables.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Probability Experiment</div>
  <div class="definition-body">
    A probability <strong>experiment</strong>  is a <strong>process or action</strong> that produces one or more <strong>possible outcomes</strong>. The specific outcome is <strong>uncertain</strong> (i.e., the specific outcome cannot be predicted in advance), but the <strong>likelihood of each outcome can be studied using the principles of probability</strong>.
  </div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Key Features</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>Experiment: </strong>The process or action is called the experiment.</li>
        <li><strong>Possible outcomes: </strong>There may be one or more outcome of the experiment and all possible outcomes make up the sample space. For example, there my be 3 outcomes of the experiment represented by 0, 1, and 2 and therefore the sample space will be $S=\{0, 1, 2\}$</li>
        <li><strong>Uncertainty: </strong>It means we cannot tell the what will be the outcome of the experiment in advance. For example, we cannot tell in advance that outcome $1$ will occur or outcome $0$ will occur.</li>
        <li><strong>Probability analysis: </strong>Although the outcomes of probability experiment are uncertain but we can apply the rules of probability to study the likelihood of each outcome. For example, we can say that there is 30% chance of occurrence of outcome $0$ etc.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Examples</h3>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Tossing a Coin: Classic Example</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>Experiment: </strong>Tossing a fair coin once is the experiment.</li>
    <li><strong>Possible outcomes: </strong>$\{Heads, Tails\}$</li>
    <li><strong>Discrete random variable $X$: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$X=1$ if head appears</li>
        <li>$X=0$ if tail appears</li>
      </ul>
    </div>
    <li><strong>Uncertainty: </strong>Before tossing, we don’t know whether it will land on Heads or Tails.</li>
    <li><strong>Probability analysis: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$P(1) = 0.5$</li>
        <li>$P(0) = 0.5$</li>
      </ul>
    </div>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Environmental Science: Rainfall on a Given Day</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>Experiment: </strong>Observing whether it rains tomorrow in your city is the experiment.</li>
    <li><strong>Possible outcomes: </strong>$\{Rain, No\;Rain\}$</li>
    <li><strong>Discrete random variable $X$: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$X=1$ if it rains</li>
        <li>$X=0$ if it doesn't rain</li>
      </ul>
    </div>
    <li><strong>Uncertainty: </strong>We don't know in advance if it rains tomorrow or not.</li>
    <li><strong>Probability analysis: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$P(1): 0.3$</li>
        <li>$P(0): 0.7$</li>
      </ul>
    </div>
  </ul>
</div>

<h3 style="font-size: 52px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Environmental Engineering: Wastewater Treatment Plant Efficiency</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li><strong>Experiment: </strong>To measure whether the treated water from a plant meets the regulatory standard (say, $BOD \lt 30\;mg/L$) on a random day.</li>
    <li><strong>Possible outcomes: </strong>$\{Meets, Not\;Meets\}$</li>
    <li><strong>Discrete random variable $X$: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$X=1$ if standard is met</li>
        <li>$X=0$ is standard is not met</li>
      </ul>
    </div>
    <li><strong>Uncertainty: </strong>You can’t know in advance whether today’s sample will meet the standard (because it depends on inflow characteristics, system performance, etc.).</li>
    <li><strong>Probability analysis: </strong></li>
    <div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
      <ul style="list-style-type:circle">
        <li>$P(1) = 0.9$</li>
        <li>$P(0) = 0.1$</li>
      </ul>
    </div>
  </ul>
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">For a water filtration system, three water samples are passed through the filtration system. The water filtration system is checked for purification of no water samples to purification of all water samples. Based on previous experiments, the probabilities are also available and the data is shown in table 1 below. Does the distribution shown in the table a discrete probability model? Also plot the distribution.</p>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 1.</strong> Probability distribution table for water purification of three water samples.</p>

<div style="font-size: 52px; line-height: 2.0;">

|$x$|Meaning|Associated Probability $P(X)$|
|:---|:---|:---|
|0|None of the samples purified|0.01|
|1|Only 1 out of 3 samples is purified|0.10|
|2|2 samples out of 3 purified|0.38|
|3|All the 3 samples purified|0.51|

</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">We already know that</p>

<div style="font-size: 52px; line-height: 2.0;">
$$
0 \le P(x) \le 1
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\sum P(x_i) =1
$$
</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">From table 1, we see that</p>

<div style="font-size: 52px; line-height: 2.0;">
$$
0 \le P(X) \le 1
$$
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\sum P(x_i) = 0.01 + 0.10 + 0.38 + 0.51 = 1
$$
</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Both conditions of probability model are fulfilled, the data in table 1 represents a discrete probability model.</p>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0301.png" width="80%" alt="fig01"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 1.</strong> Discrete probability distribution of three water samples purification through a filtration system.</figcaption>
</figure><br>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">5. Mean of Discrete Random Variable</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Suppose, there are 10 sulphuric acid manufacturing units in a city which release SO<sub>2</sub> few times a day.</li>
    <li>The units disclose the data of SO<sub>2</sub> release which is given in the following table.</li>
  </ul>
</div>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 2.</strong> Data of SO<sub>2</sub> release events per day.</p>

<div style="font-size: 52px; line-height: 2.0;">

|Sr. No.|SO<sub>2</sub> Release Events Per Day|
|:---|:---|
|1|2|
|2|4|
|3|6|
|4|6|
|5|4|
|6|4|
|7|2|
|8|3|
|9|5|
|10|5|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The mean number of SO<sub>2</sub> release events can be found using the formula for mean as shown below.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\mu = \frac{\sum x_i}{N} = \frac{2+4+6+6+4+4+2+3+5+5}{10} = 4.1
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We can find the mean another way.</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{flalign}
&\mu = \frac{\sum x_i}{N} = \frac{2+4+6+6+4+4+2+3+5+5}{10}& \\
&\mu = \frac{2+2+3+4+4+4+5+5+6+6}{10}& \\
&\mu = \frac{2.2 + 3.1 + 4.3 + 5.2 + 6.2}{10}& \\
&\mu = 2.\left(\frac{2}{10}\right) + 3.\left(\frac{1}{10}\right) + 4.\left(\frac{3}{10}\right) + 5.\left(\frac{2}{10}\right) + 6.\left(\frac{2}{10}\right) & \\
&\mu = 2.P(2) + 3.P(3) + 4.P(4) + 5.P(5) + 6.P(6)& \\
&\mu = 2(0.2) + 3(0.1) + 4(0.3) + 5(0.2) + 6(0.2)& \\
&\mu = 4.1&
\end{flalign}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The table of probabilities is shown below.</li>
  </ul>
</div>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 3.</strong> Probabilities of SO<sub>2</sub> release events.</p>

<div style="font-size: 52px; line-height: 2.0;">

|x|P(x)|
|:---|:---|
|2|$\frac{2}{10} = 0.2$|
|3|$\frac{1}{10} = 0.1$|
|4|$\frac{3}{10} = 0.3$|
|5|$\frac{2}{10} = 0.2$|
|6|$\frac{2}{10} = 0.2$|

</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We conclude that the mean of a discrete random variable is found by multiplying each possible value of the random variable by its corresponding probability and then adding these products.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Mean of Discrete Random Variable</div>
  <div class="definition-body">
    The mean of a discrete random variable is given by the formula
    <div style="font-size: 52px; line-height: 2.0;">
    $$
    \mu_X = \sum \left[ x.P(x) \right]
    $$
    </div>
    where $x$ is the value of the random variable and $P(x)$ is the probability of observing the value $x$.
  </div>
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>
<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Compute the mean number of water samples purified for the data given in table 1 of example 1.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Do it yourself using the formula given above.</p>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The mean of a discrete random variable can be thought of as the mean outcome of the probability experiment if we repeated the experiment many times.</li>
    <li> If we repeated the experiment of water purification through filter in Example 1 many tmes, we would expect the mean number of purified samples to be around 2.4.</li>
  </ul>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Interpretation of the Mean of a Discrete Random Variable</h3>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>Suppose an experiment is repeated $n$ independent times and the value of the random variable $X$ is recorded.</li>
    <li>As the number of repetitions of the experiment increases, the mean value of the $n$ trials will approach $\mu_X$, the mean of the random variable $X$.</li>
    <li>In other words, let $x_1$ be the value of the random variable $X$ after the first experiment, $x_2$ be the value of the random variable $X$ after the second experiment, and so on.</li>
    <li>In this case, the mean value is given by</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\bar x = \frac{x_1 + x_2 + \dots + x_n}{n}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The difference between $\bar x$ and $\mu_X$ gets closer to $0$ as $n$ increases.</li>
  </ul>
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 3</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">From the water filtration plant (Example) testing of 3 water samples is performed 100 times and the data of number of purified water samples is recorded as shown in table below.</p>

<p style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: center;"><strong>Table 4.</strong> Data of number of purified water samples out of 3 performed 100 times.</p>

<div style="font-size: 52px; line-height: 2.0;">
$$
\begin{align}
&3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;1\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2& \\
&2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;1\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;3& \\
&3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2& \\
&3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;1& \\
&3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;0\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;1\;\;\;\;\;\;2& \\
&3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;1\;\;\;\;\;\;3\;\;\;\;\;\;2& \\
&2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;1\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;1\;\;\;\;\;\;3\;\;\;\;\;\;3& \\
&3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;1\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;2& \\
&3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3& \\
&2\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;1\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3\;\;\;\;\;\;2\;\;\;\;\;\;3\;\;\;\;\;\;3& \\
\end{align}
$$

</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">A plot of the mean values of experiments is shown in figure below.</p>

<figure style="margin: 0 auto; text-align: center;">
  <img src="../images/0302.png" width="60%" alt="fig02"><br><br>
  <figcaption style="font-size: 52px; line-height: 2.0; text-align: center;"><strong>Figure 2.</strong> Plot of mean values against number of experiments.</figcaption>
</figure><br>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Students are advised to generate the table of probability and compute mean value using the two methods.</p>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">6. Standard Deviation of Discrete Random Variable</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>We now introduce a method for computing the standard deviation of a discrete random variable.</li>
  </ul>
</div>

<br>
<div class="definition-box">
  <div class="definition-header">Definition: Standard Deviation of Discrete Random Variable</div>
  <div class="definition-body">
    The standard deviation of a discrete random variable $X$ is given by
    <div style="font-size: 52px; line-height: 2.0;">
    $$
    \sigma_X = \sqrt{\sum \left[ (x - \mu_X)^2 . P(x) \right]}
    $$
    </div>
    where $x$ is the value of the random variable, $\mu_X$ is the mean of the random variable, and $P(x)$ is the probability of observing a value of the random variable.
  </div>
</div>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="top-box"></div>
</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Example 4</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Compute the standard deviation the data given in table 1 of example 1.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Solution</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Do it yourself.</p>

<div class="line-container">
<div class="horizontal-line"></div>
<div class="bottom-box"></div>
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">7. Summary</h2>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>A random variable is a numerical measure of the outcome of a probability experiment, so its value is determined by chance. Random variables are typically denoted using capital letters such as X.</li>
    <li>The probability distribution of a discrete random variable X provides the possible values of the random variable and their corresponding probabilities. A probability distribution can be in the form of a table, graph, or mathematical formula.</li>
    <li>The mean of a discrete random variable is given by the formula</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\mu_X = \sum {\left[ x.P(x) \right]}
$$
</div>

<div style="font-size: 52px; line-height: 2.0; padding-left: 95px; text-align: justify;">
  <ul style="list-style-type:disc">
    <li>The standard deviation of a discrete random variable is given by the formula</li>
  </ul>
</div>

<div style="font-size: 52px; line-height: 2.0;">
$$
\sigma_X = \sqrt {\sum {\left[ (x - \mu_X)^2 .P(x)\right]}}
$$
</div>

<br><br>
<h2 style="font-size: 72px; font-weight: bold; margin: 0; border-left: 40px solid red; color: black; background-color: orange; border-radius: 10px; line-height: 2.0; padding-left: 10px;">. Exercises</h2>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 1</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Which of the following distributions is a discrete probability distribution?</p>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(a)</strong></p>

<div style="font-size: 52px; line-height: 2.0;">

|$x$|$P(x)$|
|:---|:---|
|1|0.20|
|2|0.35|
|3|0.12|
|4|0.40|
|5|-0.07|

</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(b)</strong></p>

<div style="font-size: 52px; line-height: 2.0;">

|$x$|$P(x)$|
|:---|:---|
|1|0.20|
|2|0.25|
|3|0.10|
|4|0.140|
|5|0.49|

</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(a)</strong></p>

<div style="font-size: 52px; line-height: 2.0;">

|$x$|$P(x)$|
|:---|:---|
|1|0.20|
|2|0.25|
|3|0.10|
|4|0.140|
|5|0.310|

</div>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 2</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Graph the correct probability distribution(s) in Exercise 1.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 3</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">For the probability distribution of water purification from filtration system in Example 1, a researcher collects one hundred samples from the filtration system and records the number of water samples purified which are given in dataset exercise_3 (<a href="../datasets/exercise_3.xlsx" download>click to download</a>). Compute the mean number of water samples purified using the formula $\mu = \frac{\sum{x_i}}{N}$ and compare the result with the mean computed in Example 2.</p>

<h3 style="font-size: 62px; font-weight: bold; color: blue; line-height: 2.0; text-align: justify;">Exercise 4</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;">Let the random variable $x$  represents the number of lead contamination detected per liter of water in samples collected from an industrial site. The probability distribution is given in the following table.</p>

<div style="font-size: 52px; line-height: 2.0;">

|$x$|$P(x)$|
|:---|:---|
|0|0.10|
|1|0.25|
|2|0.40|
|3|0.15|
|4|0.10|

</div>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(a) </strong>Show that the model represents a discrete probability distribution model.</p>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(b) </strong>Compute the mean number of samples contaminated with lead.</p>

<p style="font-size: 52px; line-height: 2.0; text-align: justify;"><strong>(c) </strong>Compute the standard deviation of the distribution.</p>

<h3 style="font-size: 62px; font-weight: bold; color: red; line-height: 2.0; text-align: justify;">NOTE:</h3>

<p style="font-size: 52px; line-height: 2.0; text-align: justify; color: red;">The next two topics are based on the current topic. Before continuing to next topics with good understanding, complete understanding of this topic is required.</p>